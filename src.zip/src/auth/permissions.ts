/**
 * Permissions opérationnelles CADM et façon de les accorder :
 *  - par le rôle du compte (ROLE_PERMISSIONS) ;
 *  - par une désignation en cours (DESIGNATION_PERMISSIONS).
 * Source : documents « Organisation des acteurs ORSEC » (tableaux 14 à 16)
 * et « Diagrammes UML : rôles et ORSEC » (tableau 14).
 */

import type { Localized, Role } from "./roles";

export const PERMISSIONS = [
  // Administration (S1-S3)
  "CREER_COMPTE",
  "ATTRIBUER_ROLE",
  "GERER_TERRITOIRES",
  "GERER_ORGANISMES",
  "RATTACHER_COMPTE",
  "PARAMETRER_MODULES",
  "GERER_PERMISSIONS",
  // Signalements et incidents (S1-S2)
  "CREER_SIGNALEMENT",
  "CONSULTER_SIGNALEMENT",
  "VALIDER_SIGNALEMENT",
  "MODIFIER_GRAVITE",
  "CONSULTER_INCIDENTS_TERRITOIRE",
  // Veille
  "SURVEILLER_RISQUES",
  "SAISIR_NIVEAUX_EAU",
  // Organisme, moyens et missions (S3-S5)
  "GERER_EQUIPES",
  "RECENSER_MOYENS",
  "CREER_MISSION",
  "EXECUTER_MISSION",
  "SUIVRE_VEHICULE",
  "SECURISER_ZONES",
  "CONFIRMER_REOUVERTURE_ROUTE",
  // Santé et évacuations (S5-S7)
  "SUIVRE_VICTIMES",
  "GERER_EVACUATIONS",
  // Alertes (S7)
  "VALIDER_ALERTE",
  // Plan ORSEC (S8)
  "SAISIR_PLAN",
  "APPROUVER_PLAN",
  "METTRE_EN_ALERTE_PLAN",
  "DECLENCHER_PLAN",
  "LEVER_PLAN",
  "DEMANDER_DECLENCHEMENT",
  "DEMANDER_APPUI_LIMITROPHE",
  "DESIGNER_FONCTION",
  "HABILITER_PERSONNE",
  "PROGRAMMER_SIMULATION",
  "ETABLIR_RAPPORT",
  // Commandement (S8)
  "VOIR_PCF",
  "CONSOLE_PCO",
  "CHANGER_PHASE",
  "DEMANDER_RENFORT",
  "TRANSMETTRE_RENFORT",
  "TRAITER_RENFORT",
  // Transversal
  "CONSULTER_HISTORIQUE",
] as const;

export type Permission = (typeof PERMISSIONS)[number];

export const PERMISSION_LABELS: Record<Permission, Localized> = {
  CREER_COMPTE: { fr: "Créer un compte", ar: "إنشاء حساب" },
  ATTRIBUER_ROLE: { fr: "Attribuer un rôle", ar: "إسناد دور" },
  GERER_TERRITOIRES: { fr: "Gérer la wilaya et les communes", ar: "تسيير الولاية والبلديات" },
  GERER_ORGANISMES: { fr: "Gérer les organismes", ar: "تسيير الهيئات" },
  RATTACHER_COMPTE: { fr: "Rattacher un compte", ar: "إلحاق حساب" },
  PARAMETRER_MODULES: { fr: "Paramétrer les modules d'intervention", ar: "ضبط وحدات التدخل" },
  GERER_PERMISSIONS: { fr: "Gérer les permissions des rôles", ar: "تسيير صلاحيات الأدوار" },
  CREER_SIGNALEMENT: { fr: "Créer un signalement", ar: "إنشاء تبليغ" },
  CONSULTER_SIGNALEMENT: { fr: "Consulter les signalements de son organisme", ar: "الاطلاع على تبليغات هيئته" },
  VALIDER_SIGNALEMENT: { fr: "Confirmer ou rejeter un signalement", ar: "تأكيد تبليغ أو رفضه" },
  MODIFIER_GRAVITE: { fr: "Modifier la gravité (avec justification)", ar: "تعديل الخطورة (مع التبرير)" },
  CONSULTER_INCIDENTS_TERRITOIRE: { fr: "Consulter les incidents du territoire", ar: "الاطلاع على حوادث الإقليم" },
  SURVEILLER_RISQUES: { fr: "Surveiller les risques (hydro, forêts)", ar: "مراقبة المخاطر (المياه، الغابات)" },
  SAISIR_NIVEAUX_EAU: { fr: "Saisir les niveaux d'eau", ar: "إدخال مستويات المياه" },
  GERER_EQUIPES: { fr: "Gérer les équipes", ar: "تسيير الفرق" },
  RECENSER_MOYENS: { fr: "Recenser les moyens", ar: "إحصاء الوسائل" },
  CREER_MISSION: { fr: "Créer et affecter une mission", ar: "إنشاء مهمة وإسنادها" },
  EXECUTER_MISSION: { fr: "Exécuter une mission et rendre compte", ar: "تنفيذ مهمة ورفع تقرير" },
  SUIVRE_VEHICULE: { fr: "Suivre son véhicule", ar: "متابعة مركبته" },
  SECURISER_ZONES: { fr: "Sécuriser les zones et les accès", ar: "تأمين المناطق والمداخل" },
  CONFIRMER_REOUVERTURE_ROUTE: { fr: "Confirmer la réouverture d'une route", ar: "تأكيد إعادة فتح طريق" },
  SUIVRE_VICTIMES: { fr: "Suivre les victimes (données médicales)", ar: "متابعة الضحايا (معطيات طبية)" },
  GERER_EVACUATIONS: { fr: "Gérer les évacuations", ar: "تسيير عمليات الإخلاء" },
  VALIDER_ALERTE: { fr: "Valider et diffuser une alerte", ar: "المصادقة على تنبيه وبثه" },
  SAISIR_PLAN: { fr: "Saisir un plan ORSEC", ar: "إدخال مخطط ORSEC" },
  APPROUVER_PLAN: { fr: "Approuver un plan", ar: "المصادقة على مخطط" },
  METTRE_EN_ALERTE_PLAN: { fr: "Mettre un plan en état d'alerte", ar: "وضع مخطط في حالة تأهب" },
  DECLENCHER_PLAN: { fr: "Déclencher un plan", ar: "إطلاق مخطط" },
  LEVER_PLAN: { fr: "Lever un plan", ar: "رفع مخطط" },
  DEMANDER_DECLENCHEMENT: { fr: "Demander le déclenchement du plan", ar: "طلب إطلاق المخطط" },
  DEMANDER_APPUI_LIMITROPHE: { fr: "Demander l'appui d'une wilaya limitrophe", ar: "طلب دعم ولاية مجاورة" },
  DESIGNER_FONCTION: { fr: "Désigner une fonction (modules, représentants)", ar: "تعيين وظيفة (وحدات، ممثلون)" },
  HABILITER_PERSONNE: { fr: "Habiliter une personne à valider les alertes", ar: "تأهيل شخص للمصادقة على التنبيهات" },
  PROGRAMMER_SIMULATION: { fr: "Programmer les simulations", ar: "برمجة المحاكاة" },
  ETABLIR_RAPPORT: { fr: "Établir le rapport détaillé", ar: "إعداد التقرير المفصّل" },
  VOIR_PCF: { fr: "Consulter le PCF", ar: "الاطلاع على مركز القيادة الثابت" },
  CONSOLE_PCO: { fr: "Utiliser la console du PCO", ar: "استعمال وحدة تحكم مركز القيادة العملياتي" },
  CHANGER_PHASE: { fr: "Changer la phase de l'activation", ar: "تغيير مرحلة التفعيل" },
  DEMANDER_RENFORT: { fr: "Demander un renfort", ar: "طلب تعزيز" },
  TRANSMETTRE_RENFORT: { fr: "Transmettre une demande de renfort", ar: "إحالة طلب تعزيز" },
  TRAITER_RENFORT: { fr: "Accepter ou refuser un renfort", ar: "قبول تعزيز أو رفضه" },
  CONSULTER_HISTORIQUE: { fr: "Consulter l'historique", ar: "الاطلاع على السجل" },
};

/* ------------------------------------------------------------------ */
/* Permissions accordées par le rôle                                   */
/* ------------------------------------------------------------------ */

const SIGNALEMENT_ORGANISME: Permission[] = [
  "CONSULTER_SIGNALEMENT",
  "VALIDER_SIGNALEMENT",
  "MODIFIER_GRAVITE",
];

const AUTORITE_COMMUNE_WILAYA: Permission[] = [
  "CONSULTER_INCIDENTS_TERRITOIRE",
  "APPROUVER_PLAN",
  "METTRE_EN_ALERTE_PLAN",
  "DECLENCHER_PLAN",
  "LEVER_PLAN",
  "VALIDER_ALERTE",
  "DESIGNER_FONCTION",
  "HABILITER_PERSONNE",
  "PROGRAMMER_SIMULATION",
  "ETABLIR_RAPPORT",
  "CONSULTER_HISTORIQUE",
];

export const ROLE_PERMISSIONS: Record<Role, readonly Permission[]> = {
  citizen: ["CREER_SIGNALEMENT"],
  farmer: ["CREER_SIGNALEMENT"],
  organism: [...SIGNALEMENT_ORGANISME, "CREER_MISSION", "RECENSER_MOYENS"],
  admin: [
    "CREER_COMPTE",
    "ATTRIBUER_ROLE",
    "GERER_TERRITOIRES",
    "GERER_ORGANISMES",
    "RATTACHER_COMPTE",
    "PARAMETRER_MODULES",
    "GERER_PERMISSIONS",
  ],
  wali: [...AUTORITE_COMMUNE_WILAYA, "DEMANDER_APPUI_LIMITROPHE"],
  apc_president: AUTORITE_COMMUNE_WILAYA,
  minister: [
    "CONSULTER_INCIDENTS_TERRITOIRE",
    "METTRE_EN_ALERTE_PLAN",
    "DECLENCHER_PLAN",
    "LEVER_PLAN",
    "DESIGNER_FONCTION",
    "DEMANDER_APPUI_LIMITROPHE",
    "ETABLIR_RAPPORT",
    "CONSULTER_HISTORIQUE",
  ],
  site_operator: [
    "CREER_SIGNALEMENT",
    "SAISIR_PLAN",
    "DECLENCHER_PLAN",
    "LEVER_PLAN",
    "PROGRAMMER_SIMULATION",
    "ETABLIR_RAPPORT",
    "RECENSER_MOYENS",
  ],
  forecaster: ["SURVEILLER_RISQUES", "SAISIR_NIVEAUX_EAU"],
  forestry_agent: ["CREER_SIGNALEMENT", "SURVEILLER_RISQUES", "RECENSER_MOYENS"],
  org_director: [
    ...SIGNALEMENT_ORGANISME,
    "CREER_SIGNALEMENT",
    "GERER_EQUIPES",
    "RECENSER_MOYENS",
    "CREER_MISSION",
    "TRANSMETTRE_RENFORT",
    "TRAITER_RENFORT",
    "VOIR_PCF",
    "CONSULTER_HISTORIQUE",
  ],
  unit_lead: [
    ...SIGNALEMENT_ORGANISME,
    "CREER_SIGNALEMENT",
    "GERER_EQUIPES",
    "RECENSER_MOYENS",
    "CREER_MISSION",
    "DEMANDER_RENFORT",
  ],
  pc_lead: [
    ...SIGNALEMENT_ORGANISME,
    "CREER_SIGNALEMENT",
    "RECENSER_MOYENS",
    "CREER_MISSION",
    "SUIVRE_VICTIMES",
    "GERER_EVACUATIONS",
    "SAISIR_PLAN",
    "DEMANDER_DECLENCHEMENT",
    "TRANSMETTRE_RENFORT",
    "TRAITER_RENFORT",
    "CONSULTER_HISTORIQUE",
  ],
  medical_lead: [
    "CREER_SIGNALEMENT",
    "EXECUTER_MISSION",
    "RECENSER_MOYENS",
    "SUIVRE_VICTIMES",
    "DEMANDER_RENFORT",
  ],
  evac_lead: [
    "CREER_SIGNALEMENT",
    "EXECUTER_MISSION",
    "RECENSER_MOYENS",
    "GERER_EVACUATIONS",
    "DEMANDER_RENFORT",
  ],
  pc_agent: ["CREER_SIGNALEMENT", "EXECUTER_MISSION", "RECENSER_MOYENS"],
  engine_chief: [
    "CREER_SIGNALEMENT",
    "EXECUTER_MISSION",
    "RECENSER_MOYENS",
    "SUIVRE_VEHICULE",
  ],
  police: [
    "CREER_SIGNALEMENT",
    "EXECUTER_MISSION",
    "SECURISER_ZONES",
    "CONFIRMER_REOUVERTURE_ROUTE",
  ],
  gendarmerie: [
    "CREER_SIGNALEMENT",
    "EXECUTER_MISSION",
    "SECURISER_ZONES",
    "CONFIRMER_REOUVERTURE_ROUTE",
  ],
  coast_guard: ["CREER_SIGNALEMENT", "EXECUTER_MISSION", "RECENSER_MOYENS"],
  emergency_doctor: [
    "CREER_SIGNALEMENT",
    "EXECUTER_MISSION",
    "SUIVRE_VICTIMES",
    "DEMANDER_RENFORT",
  ],
  org_agent: [
    "CREER_SIGNALEMENT",
    "EXECUTER_MISSION",
    "RECENSER_MOYENS",
    "CONFIRMER_REOUVERTURE_ROUTE",
  ],
};

/* ------------------------------------------------------------------ */
/* Désignations ORSEC (fonctions confiées pendant un plan)             */
/* ------------------------------------------------------------------ */

export const DESIGNATION_FNS = [
  "AUTHORITY_REPRESENTATIVE",
  "PCF_DIRECTOR",
  "PCO_DIRECTOR",
  "MODULE_MANAGER",
  "MODULE_REPRESENTATIVE",
  "ALERT_VALIDATOR",
] as const;

export type DesignationFn = (typeof DESIGNATION_FNS)[number];

export const DESIGNATION_LABELS: Record<DesignationFn, Localized> = {
  AUTHORITY_REPRESENTATIVE: { fr: "Représentant de l'autorité", ar: "ممثل السلطة" },
  PCF_DIRECTOR: { fr: "Directeur du PCF", ar: "مدير مركز القيادة الثابت" },
  PCO_DIRECTOR: { fr: "Directeur du PCO", ar: "مدير مركز القيادة العملياتي" },
  MODULE_MANAGER: { fr: "Responsable de module", ar: "مسؤول وحدة" },
  MODULE_REPRESENTATIVE: { fr: "Représentant de module au PCO", ar: "ممثل وحدة في مركز القيادة العملياتي" },
  ALERT_VALIDATOR: { fr: "Personne habilitée à valider les alertes", ar: "شخص مؤهل للمصادقة على التنبيهات" },
};

export const DESIGNATION_PERMISSIONS: Record<DesignationFn, readonly Permission[]> = {
  AUTHORITY_REPRESENTATIVE: ["CONSULTER_INCIDENTS_TERRITOIRE"],
  PCF_DIRECTOR: ["VOIR_PCF", "CHANGER_PHASE", "HABILITER_PERSONNE", "CONSULTER_HISTORIQUE"],
  PCO_DIRECTOR: ["CONSOLE_PCO", "DEMANDER_RENFORT", "CONSULTER_HISTORIQUE"],
  MODULE_MANAGER: ["RECENSER_MOYENS", "TRANSMETTRE_RENFORT", "TRAITER_RENFORT", "ETABLIR_RAPPORT"],
  MODULE_REPRESENTATIVE: [],
  ALERT_VALIDATOR: ["VALIDER_ALERTE"],
};

/**
 * Désignation accordée « de droit » par le rôle (décret 19-59, art. 31 et 38) :
 * le responsable de la Protection civile du territoire dirige le PCO.
 */
export const IMPLICIT_DESIGNATIONS: Partial<Record<Role, DesignationFn[]>> = {
  pc_lead: ["PCO_DIRECTOR"],
};
